import React from 'react';

const MyCustomComponent = () => {
    return (
        <div className="bg-blue-500 text-white p-4 rounded-lg">
            <h1 className="text-xl font-bold">Custom Component</h1>
            <p className='border'>This is a custom React component rendered only on the Medals & Ribbons category page.</p>
        </div>
    );
};

export default MyCustomComponent;
